
<?php

    $em = $_GET['email'];

    $intentos = 0;

    $letrasProbadas = array();


?>


<html>
    <head>
        <title>Inicio</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        <link rel="stylesheet" href="assets/css/juego.css" />
        <link rel="stylesheet" href="assets/css/main.css" />
    </head>

    <body>
    <script></script>
    <section>

        <h1>Juego del ahorcado</h1>

    </section>


    <section id="main" class="container" onload="">
        <script src="assets/js/juego.js"></script>
        <div id="dibujo">
            
        </div>

        <form action="comprobar.php">
            <input id="texto" type="text" ></input>
            <input id="resolver" type="submit" value="Resolver"></input>
        </form>
        



        <div class="letras"> 
            <button onclick="comprobarA()" id="a" class="abecedario"> A</button>
            <button onclick="comprobarB()"  id="b" class="abecedario" > B</button>
            <button onclick="comprobarC()"  id="c" class="abecedario"> C</button>
            <button onclick="comprobarD()"  id="d" class="abecedario" > D</button>
            <button onclick="comprobarE()"  id="e" class="abecedario"> E</button>
            <button onclick="comprobarF()"  id="f" class="abecedario"> F</button>
            <button onclick="comprobarG()"  id="g" class="abecedario"> G</button>
            <button onclick="comprobarH()"  id="h" class="abecedario"> H</button>
            <button onclick="comprobarI()"  id="i" class="abecedario"> I</button>
            <button onclick="comprobarJ()"  id="j" class="abecedario" > J</button>
            <button onclick="comprobarK()"  id="k" class="abecedario"> K</button>
            <button onclick="comprobarL()"  id="l" class="abecedario"> L</button>
            <button onclick="comprobarM()"  id="m" class="abecedario"> M</button>
            <button onclick="comprobarN()"  id="n" class="abecedario"> N</button>
            <button onclick="comprobarÑ()"  id="ñ" class="abecedario" > Ñ</button>
            <button onclick="comprobarO()"  id="o" class="abecedario"> O</button>
            <button onclick="comprobarP()"  id="p" class="abecedario"> P</button>
            <button onclick="comprobarQ()"  id="q" class="abecedario"> Q</button>
            <button onclick="comprobarR()"  id="r" class="abecedario"> R</button>
            <button onclick="comprobarS()"  id="s" class="abecedario"> S</button>
            <button onclick="comprobarT()"  id="t" class="abecedario"> T</button>
            <button onclick="comprobarU()"  id="u" class="abecedario"> U</button>
            <button onclick="comprobarV()"  id="v" class="abecedario"> V</button>
            <button onclick="comprobarW()"  id="w" class="abecedario"> W</button>
            <button onclick="comprobarX()"  id="x" class="abecedario"> X</button>
            <button onclick="comprobarY()"  id="y" class="abecedario"> Y</button>
            <button onclick="comprobarZ()"  id="z" class="abecedario"> Z</button>

            <article>
            <a href="inicio.php"> Salir</a>
            </article>
            
        </div>
        <a href="inicio.php"> Salir</a>
        </section>

        
        
    </body>
</html>