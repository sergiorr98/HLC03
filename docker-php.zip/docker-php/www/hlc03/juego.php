<?php
    session_start();

    //Array de las palabras secretas
    $array_palabras = array(
        1 => "DORAMIO",
        2 => "POLVORA",
        3 => "JARDINERIA",
        4 => "EVERIS",
        5 => "MINECRAFT",
        6 => "APLICACION",
        7 => "LUGAR",
        8 => "DOCUMENTO",
        9 => "GUARDAR",
        10 => "CACAHUETE",
        11 => "JUAN",
        12 => "BELEÑO",
        13 => "PAJUELAS",
    );
    
    if ($_SESSION['jugando']==0)
    {
        //Generamos el numero aleatorio entre 1 y 10 
        $indice = rand(1, 13);
        
        $intentos = 0;
        //Se le asigna a nuestra variable de palabra una del array con el indice generado aleatoriamente
        $palabra_secreta = $array_palabras[1];
        $arrayPalabraSecreta = array();

        

        //Otra forma sin terminar
        //Se recoge el numero de caracteres de la palabra secreta
        $numero_caracteres = strlen($palabra_secreta);

        $palabra_intento = array();

        for($i=0; $i<$numero_caracteres; $i++)
        {
            $palabra_intento[] = "_";
        }

        for($i=0; $i<$numero_caracteres; $i++)
        {
            $arrayPalabraSecreta[] = $palabra_secreta[$i];
        }

        $_SESSION['email'] = $_GET['email'];
    

        $_SESSION['intento'] = $palabra_intento;
        $_SESSION['secreta'] = $arrayPalabraSecreta;
        $_SESSION['caracteres']=$numero_caracteres;
        $_SESSION['intentos'] = $intentos;
    }



?>


<html>
    <head>
        <title>Inicio</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        <link rel="stylesheet" href="assets/css/juego.css" />
        <link rel="stylesheet" href="assets/css/main.css" />
    </head>

    <body>
    <section>

        <h1>Juego del ahorcado</h1>

    </section>


    <section id="main" class="container" onload="">
        <script src="assets/js/juego.js"></script>


        <div id="dibujo">
            <image src="fotoshangman/<?php echo  $_SESSION['intentos'] ?>.jpg"> </image>
        </div>

        <div id="intento">

            <dl>
            <?php
                for($j=0; $j<$_SESSION['caracteres']; $j++)
                {
            ?>
                <dt><?php echo $_SESSION['intento'][$j]." "?></dt>
            
            <?php
                }
            ?>
            </ul>
        </div>


        <form action="comprobar.php" method="post">
            
            <input id="texto" name="letra" type="text" ></input>
            <input id="resolver" type="submit" value="Resolver" class="button"></input>
        </form>
        



        <div class="letras"> 
           
            <article>
                <a href="perder.php"> Rendirse</a>
            </article>
            
        </div>
        </section>

        
        
    </body>
</html>