<?php
    session_start();
    $em = $_SESSION['email'];
    $conn = mysqli_connect('localhost','usuario','1234','db');
    $sql = "update jugador set ganadas=ganadas+1 where email='$em';";
    $result = mysqli_query($conn,$sql);
?>

<html>
    <body>
        <h1>HAS GANADO</h1>
        <h3>En 2 seg. seras redirigido...</h3>
    </body>
</html>

<script>
        window.setTimeout(function(){window.location.replace('http://localhost/hlc03/inicio.php');}, 2700);
</script>