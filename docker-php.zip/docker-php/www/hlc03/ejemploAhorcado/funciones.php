<?php
	function abre_www($titulo)
	{
		$salida= <<<TXT
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html 
     PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="sp" lang="sp">
  <head>
    <title>$titulo</title>
  </head>
  <body>
TXT;
		return $salida;
	}

	function cierra_www()
	{
		$salida = <<<TXT
  </body>
</html>
TXT;
		return $salida;
	}

	function pizarra($palabra, $letras)
	{
		// Recorremos cada letra de $palabra buscando si esa letra
		// ya est� en $letras para imprimir la letra o un gui�n seg�n corresponda.
		$letras_de_palabra = strlen($palabra);
		$salida="";
		for($i=0; $i<$letras_de_palabra; $i++)
		{
			$letra = $palabra{$i};
			strpos($letras, $letra)?$salida.=$letra:$salida.="-";
		}
		return "<p>Pizarra: $salida</p>\n";
	}

	function estado_partida($sesion)
	{
		$n_intentos = $sesion["intentos"];
		$salida = "<p>N�mero de intentos: <strong>$n_intentos</strong></p>\n";
		$intentos_restantes = $sesion["max_intentos"] - $n_intentos;
		if ($intentos_restantes==0) $salida .= "<h1>Ops, ha perdido !!!</h1>";
		$salida .= "<p>Intentos restantes: <strong>$intentos_restantes</strong></p>\n";
		$salida .= "<p>Letras probadas: <pre>" . $sesion["letras"] . "</pre></p>";
		return $salida;
	}

	function formulario()
	{
		$salida = <<<TXT
<form action="ahorcado.php" method="post">
	<p>Letra: <input type="text" name="letra"/></p>
	<input type="submit"/>
</form>
TXT;
		return $salida;
	}

	function hemos_ganado($palabra, $letras)
	{
		// Recorremos cada letra de $palabra buscando si esa letra
		// ya est� en $letras. Si todas est�n hemos ganado.
		$letras_de_palabra = strlen($palabra);
		$salida=true;
		for($i=0; $i<$letras_de_palabra; $i++)
		{
			$letra = $palabra{$i};
			if(!strpos($letras, $letra)) {$salida=false;}
		}
		return $salida;
	}

	function formulario_principal()
	{
		$salida = <<<TXT
<form action="ahorcado.php" method="post">
	<p>Palabra: <input type="text" name="palabra"/></p>
	<p>Intentos: <input type="text" name="max_intentos"/></p>
	<input type="submit"/>
</form>		
TXT;
		return $salida;
	}

	function juega() {
		// Ya hay una partida en marcha, y el usuario ha probado
		// una nueva letra.
		if (isset($_POST["letra"])) {
			$_SESSION["letras"] .= $_POST["letra"];
			$_SESSION["intentos"]++;
		}
		echo abre_www("Partida de Ahorcado");
		echo pizarra($_SESSION["palabra"], $_SESSION["letras"]);
		echo estado_partida($_SESSION);
		echo formulario();
		if(hemos_ganado($_SESSION["palabra"], $_SESSION["letras"])) {
			echo "<h1>Hemos ganado</h1>";
		}
		echo cierra_www();
	}
?>