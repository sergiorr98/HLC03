<?php
	// Recupero o abro una sesi�n nueva
	session_start();
	
	include("funciones.php");

	// Hay una partida en curso

	// Si vengo desde el formulario de inicio de partida
	// tengo que comenzar una nueva partida,
	// en caso contrario continuo con una partida en marcha.
	if(isset($_POST["palabra"]))
	{
		// Vengo del formulario, por lo tanto inicio una partida
		$_SESSION["palabra"]=$_POST["palabra"];
		$_SESSION["max_intentos"]=$_POST["max_intentos"];
		$_SESSION["partida_en_curso"]=true;
		$_SESSION["intentos"]=0;
		$_SESSION["letras"]="";
		juega();
	}
	else
	{
		if($_SESSION["partida_en_curso"]==true)
		{
			juega();
		}
		else
		{
			echo abre_www("Bienvenidos al juego del ahorcado");
			echo formulario_principal();
			echo cierra_www();
		}
	}	
?>