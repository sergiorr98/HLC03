<?php
    session_start();
    $_SESSION['intentos'] +=1;
    header("Location: juego.php");
?>