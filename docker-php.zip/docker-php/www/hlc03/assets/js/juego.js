

function comprobarA()
{
    var idLetra = document.getElementById('a');
    idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarB()
{
    var idLetra = document.getElementById('b');
    idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarC()
{
    var idLetra = document.getElementById('c');
    idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarD()
{
    var idLetra = document.getElementById('d');
    idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarE()
{
    var idLetra = document.getElementById('e');
    idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarF()
{
    var idLetra = document.getElementById('f');
    idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarG()
{
    var idLetra = document.getElementById('g');
    idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarH()
{
    var idLetra = document.getElementById('h');
    idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarI()
{
    var idLetra = document.getElementById('i');
idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarJ()
{
    var idLetra = document.getElementById('j');
idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarK()
{
    var idLetra = document.getElementById('k');
idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarL()
{
    var idLetra = document.getElementById('l');
idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarM()
{
    var idLetra = document.getElementById('m');
idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarN()
{
    var idLetra = document.getElementById('n');
idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarÑ()
{
    var idLetra = document.getElementById('ñ');
idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarO()
{
    var idLetra = document.getElementById('o');
idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarP()
{
    var idLetra = document.getElementById('p');
idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarQ()
{
    var idLetra = document.getElementById('q');
idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarR()
{
    var idLetra = document.getElementById('r');
idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarS()
{
    var idLetra = document.getElementById('s');
idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarT()
{
    var idLetra = document.getElementById('t');
idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarU()
{
    var idLetra = document.getElementById('u');
idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarV()
{
    var idLetra = document.getElementById('v');
idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarW()
{
    var idLetra = document.getElementById('w');
idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarX()
{
    var idLetra = document.getElementById('x');
idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarY()
{
    var idLetra = document.getElementById('y');
idLetra.id = "apagado";
    idLetra.disabled = true;
}

function comprobarZ()
{
    var idLetra = document.getElementById('z');
idLetra.id = "apagado";
    idLetra.disabled = true;
}