<?php
    /*
    Cuando se conecta hay que pasar los parametros de direccion del pc( no vale con localhost), usuario, contraseña y nombre de la base de datos 
    Se hace un print_r a lo que devuelve para ver la informacion que nos da aunque solo es a nivel formativo
    Se hace el echo <pre> para provocar un reseteo y se vea correctamente
    */
    $conn = mysqli_connect('192.168.137.132','usuario','1234','db');
    //echo "<pre>";
    //print_r($conn);

    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $email = $_POST['email'];
    $fecha = $_POST['fecha'];
    $sql = "INSERT INTO jugador VALUES ('$nombre','$apellido','$email','$fecha',0,0);";

    //$sql = "SELECT COUNT(*) FROM jugador";
    
    $result = mysqli_query($conn,$sql);
    //print_r ($result); Muestra 1 si todo se ha llevado a cabo de forma satisfactoria y 0 en caso de error
?>
    <script>
        window.location.replace('http://localhost/hlc03/inicio.php');
    </script>



                        
