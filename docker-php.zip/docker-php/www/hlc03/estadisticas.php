<!DOCTYPE HTML>
<html>
	<?php
		$conn = mysqli_connect('192.168.59.128','usuario','1234','db');

		$sql = "select * from jugador;";

		$result = mysqli_query($conn,$sql);
	?>
							
	<head>
		<title>Inicio</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="assets/css/efectos.css" />
	</head>
	<body class="landing is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header" class="alt">
					<h1>Web del ahorcado - Estadisticas</h1>
					<nav id="nav">
						<ul>
							<li><a href="inicio.php">Home</a></li>
							<li><a href="estadisticas.php"> Estadisticas</a></li>
							<li><a href="alta.php" class="button">Dar de alta</a></li>
						</ul>
					</nav>
				</header>

			<!-- Banner -->
				<section id="banner">
					
				</section>

			<!-- Main -->
				<section id="main" class="container" onload="">

					<section class="box special">
						<header class="major">
					
							<table class="usuarios">
								<tr id="columnas">
											<td>Nombre</td>
											<td>Apellido</td>
											<td>Email</td>
											<td>Ganadas</td>
											<td>Perdidas</td>
								</tr>	
								<?php if(mysqli_num_rows($result)==0): ?>
									<td>No hay usuarios</td>
								<?php else: ?>
								<?php 
									$contador = 0;
									$users = array();
									while ($users = mysqli_fetch_array($result)) {
										$em = $users["email"];	

									?>
										
										<tr>
											<td> <?php echo $users["nombre"] ?></td>
											<td> <?php echo $users["apellido"] ?></td>
											<td> <?php echo $users["email"] ?></td>
											<td> <?php echo $users["ganadas"] ?></td>
											<td> <?php echo $users["perdidas"] ?></td>
										</tr>
									<?php 
									
										}
									?>
								<?php endif; ?>
							</table>
						</header>
						
					</section>

					

					

				</section>

			<!-- CTA -->
				<section id="cta">

					<form>
						<div class="row gtr-50 gtr-uniform">
							<div class="col-8 col-12-mobilep">
								
							</div>
							<div class="col-4 col-12-mobilep">
								
							</div>
						</div>
					</form>

				</section>

			<!-- Footer -->
				<footer id="footer">
					<ul class="icons">
						<li><a href="#" class="icon brands fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon brands fa-facebook-f"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon brands fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon brands fa-github"><span class="label">Github</span></a></li>
						<li><a href="#" class="icon brands fa-dribbble"><span class="label">Dribbble</span></a></li>
						<li><a href="#" class="icon brands fa-google-plus"><span class="label">Google+</span></a></li>
					</ul>
					<ul class="copyright">
						<li>Design: Jorge Herrera, Sergio Ruiz</li>
					</ul>
				</footer>

		</div>

		<!-- Scripts -->
		<script src="assets/js/jquery.min.js"></script>
		<script src="assets/js/jquery.dropotron.min.js"></script>
		<script src="assets/js/jquery.scrollex.min.js"></script>
		<script src="assets/js/browser.min.js"></script>
		<script src="assets/js/breakpoints.min.js"></script>
		<script src="assets/js/util.js"></script>
		<script src="assets/js/main.js"></script>

	</body>
</html>
