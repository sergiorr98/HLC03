<?php
    session_start();
    $_SESSION['jugando'] = 1;
    $letra = $_POST['letra'];


    function iguales()
    {
        $entrado = 0;

        for ($i=0; $i<$_SESSION['caracteres']; $i++)
        {
            if(strnatcasecmp($_SESSION['intento'][$i], $_SESSION['secreta'][$i]) == 0)
            {
                $entrado = 1;
            }
            else
            {
                return false;
            }
        }

        if($entrado == 1)
        {
            return true;
        }
    }

    if ($_SESSION['intentos']==9)
    {
        header("Location: perder.php");   
    }
    elseif (iguales()){
        header("Location: ganar.php");  
    }
    else
    {
            $entrado = 0;

            for ($i=0; $i<$_SESSION['caracteres']; $i++)
            {
                if(strnatcasecmp($letra, $_SESSION['secreta'][$i]) == 0)
                {
                    $_SESSION['intento'][$i] = $letra;
                    $entrado = 1;
                }
            }

            if ($entrado ==0)
            {
                header("Location: modificarIntentos.php");
            }
            else
            {
                if(iguales()){
                    header("Location: ganar.php");  
                }
                else
                {
                    header("Location: juego.php");  
                }
                           
            }

            

     }


    
?>
