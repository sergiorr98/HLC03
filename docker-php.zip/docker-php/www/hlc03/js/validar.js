function validar()
{

	var banderaEmail = comprobarCorreo();
	
		if (banderaEmail == false)
			return false;
}

function comprobarCorreo()
{
	var expresion =/\w+@\w+\.+[a-z]/; /*Se crea una expresion que coincidad con "texto@texto.texto(a-z)"*/
	var correo = document.getElementById("email").value;
	if (correo == "")
	{
		alert("El campo correo no puede estar vacio");
		console.log("Error campo vacio");
		return false;
	}
	else if(!expresion.test(correo))
	{
		alert("Correo mal escrito");
		console.log("Error campo correo electronico");
		return false;
	}
	return true;
}